// 文件系统模块
const fs = require("fs");

// read a file 同步
// var readMe = fs.readFileSync("readMe.txt","utf8");
// console.log(readMe);

// write a file 同步
// fs.writeFileSync("writeMe.txt","Hello World");

// read a file 异步
// fs.readFile("readMe.txt","utf8",function (err,data) {
//     if (err) throw err;
//     console.log(data);
// });

// console.log(1111); 测试异步

// write a file 异步
// fs.readFile("readMe.txt","utf8",function (err,data) {
//     if (err) throw err;
//     fs.writeFile("writeMe2.txt",data);
// });
