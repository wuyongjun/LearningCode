require("./Bucky");
require("./Emily");

// 伏笔: 模块共享是属于耦合度很高了, 要解决模块独立!
