var bucky = require('./movies');

bucky.favMovies = "肖申克救赎!";

console.log(bucky.favMovies);
