var emily = require('./movies');

console.log(emily.favMovies);

emily.favMovies = "卧虎藏龙";

// 对象的引用