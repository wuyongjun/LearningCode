module.exports = {
    favMovies: ""
};