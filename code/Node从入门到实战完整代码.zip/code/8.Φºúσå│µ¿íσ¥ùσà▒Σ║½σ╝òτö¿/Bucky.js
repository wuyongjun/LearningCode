var bucky = require('./movies');

var buckyMovie = bucky();

buckyMovie.favMovies = "肖申克救赎!";

console.log(buckyMovie.favMovies);
