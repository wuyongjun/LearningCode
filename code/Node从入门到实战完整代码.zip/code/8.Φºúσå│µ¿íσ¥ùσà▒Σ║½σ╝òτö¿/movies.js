// 使用工厂模式解决对象共享问题
module.exports = function () {
    return {
        favMovies: ""
    }
}
