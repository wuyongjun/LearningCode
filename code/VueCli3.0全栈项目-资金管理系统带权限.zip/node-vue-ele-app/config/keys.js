module.exports = {
  mongoURI: 'mongodb://test:test1234@ds131942.mlab.com:31942/node-vue-element',
  secretOrKey: 'secret'
};
