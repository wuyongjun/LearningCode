module.exports = {
  mongoURI: "mongodb://mern:abc123@ds127841.mlab.com:27841/restful-api-mern",
  secretOrKey: "secret"
}