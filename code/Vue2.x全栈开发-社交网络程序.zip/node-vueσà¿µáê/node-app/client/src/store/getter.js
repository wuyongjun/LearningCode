export const isAutnenticated = state => state.isAutnenticated;
export const user = state => state.user;
export const profile = state => state.profile;
export const loading = state => state.loading;
export const profiles = state => state.profiles;
