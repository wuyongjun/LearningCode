<template>
    <footer class="bg-dark text-white mt-5 p-4 text-center">
        Copyright &copy; 2018 米修在线
    </footer>
</template>

<script>
export default {
  name: "Footer",
  data() {
    return {};
  }
};
</script>

<style scoped>
</style>