module.exports = {
  mongoURI: '换你自己的链接地址',
  secretOrKey: 'secret'
};
