module.exports = {
  mongoURI: '写你自己的',
  secretOrKey: 'secret'
};
